<?php
/**
 * Created by PhpStorm.
 * User: Alan
 * Date: 14-3-19
 * Time: 上午9:26
 */
class CheckinModel extends Model
{

}


